
youtube_url = "https://youtube.com/shorts/D-F32ieZ4WA?si=X7QzBXMEuJM6d-E4" 
backend = "gemini-1.5-flash" 

prompt = "Summarize the video **into** a conversation between two people. Denote first speaker as 'Person 1' and second speaker as 'Person 2'."

NB: audio tts used emotion as 'curiosity'

### Summary: 
Person 1: Did you know that giant clams are more efficient at converting energy from the sun than solar panels or even leaves?
Person 2: That's really interesting! What's their secret?
Person 1: They have algae living inside them. The algae takes light from the sun and converts it to energy for itself and the clam.
Person 2: Wow! So we could learn from them to make better solar energy?
Person 1: That's right. People are trying to extract energy from algae, but our current process is only 10% efficient. These clams are 67% efficient.
Person 2: How do they do it?
Person 1: It's because of these shimmery cells on the clam. They reflect sunlight down onto the algae inside the clam, evenly coating them with the perfect dose of light.
Person 2: Fascinating! There's so much to learn from nature. 